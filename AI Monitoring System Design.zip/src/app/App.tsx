import { useState, useEffect } from "react";
import { Toaster } from "./components/ui/sonner";
import { WelcomeScreen } from "./components/WelcomeScreen";
import { OnboardingFlow } from "./components/OnboardingFlow";
import { PatientDashboard } from "./components/PatientDashboard";
import { DoctorDashboard } from "./components/DoctorDashboard";
import { MonitoringSession } from "./components/MonitoringSession";
import { SystemArchitecture } from "./components/SystemArchitecture";
import { Button } from "./components/ui/button";
import { UserCircle, Stethoscope, FileText } from "lucide-react";

export type UserRole = "patient" | "doctor" | null;

export interface PatientProfile {
  name: string;
  age: number;
  diagnosisDate: string;
  medicationSchedule: string[];
  baselineQuestionnaire: any;
  riskLevel: "low" | "moderate" | "high";
}

export interface MonitoringData {
  date: string;
  sessionId: string;
  duration: number;
  riskScore: number;
  breathingRate: number[];
  alerts: Alert[];
  interventionsUsed: string[];
}

export interface Alert {
  id: string;
  timestamp: string;
  severity: "low" | "moderate" | "critical";
  type: string;
  description: string;
  resolved: boolean;
  intervention?: string;
}

function App() {
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [hasOnboarded, setHasOnboarded] = useState(false);
  const [patientProfile, setPatientProfile] = useState<PatientProfile | null>(null);
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [monitoringHistory, setMonitoringHistory] = useState<MonitoringData[]>([]);
  const [showDocs, setShowDocs] = useState(false);

  // Load saved data from localStorage
  useEffect(() => {
    const savedProfile = localStorage.getItem("patientProfile");
    const savedHistory = localStorage.getItem("monitoringHistory");
    
    if (savedProfile) {
      setPatientProfile(JSON.parse(savedProfile));
      setHasOnboarded(true);
    }
    
    if (savedHistory) {
      setMonitoringHistory(JSON.parse(savedHistory));
    }
  }, []);

  // Save profile to localStorage
  useEffect(() => {
    if (patientProfile) {
      localStorage.setItem("patientProfile", JSON.stringify(patientProfile));
    }
  }, [patientProfile]);

  // Save monitoring history to localStorage
  useEffect(() => {
    if (monitoringHistory.length > 0) {
      localStorage.setItem("monitoringHistory", JSON.stringify(monitoringHistory));
    }
  }, [monitoringHistory]);

  const handleOnboardingComplete = (profile: PatientProfile) => {
    setPatientProfile(profile);
    setHasOnboarded(true);
  };

  const handleMonitoringComplete = (data: MonitoringData) => {
    setMonitoringHistory(prev => [data, ...prev]);
    setIsMonitoring(false);
  };

  const handleReset = () => {
    if (confirm("Are you sure you want to reset all data? This cannot be undone.")) {
      localStorage.clear();
      setUserRole(null);
      setHasOnboarded(false);
      setPatientProfile(null);
      setMonitoringHistory([]);
    }
  };

  // Welcome screen - choose role
  if (!userRole) {
    return (
      <>
        <WelcomeScreen onSelectRole={setUserRole} />
        <div className="fixed bottom-4 right-4">
          <Button
            size="lg"
            variant="secondary"
            className="shadow-lg"
            onClick={() => {
              setShowDocs(true);
              setUserRole("patient");
            }}
          >
            <FileText className="w-5 h-5 mr-2" />
            View System Documentation
          </Button>
        </div>
        <Toaster />
      </>
    );
  }

  // System documentation view
  if (showDocs) {
    return (
      <>
        <div className="min-h-screen bg-slate-50">
          <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
            <div className="container mx-auto px-4 py-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <FileText className="w-8 h-8 text-blue-600" />
                <div>
                  <h1>System Documentation</h1>
                  <p className="text-sm text-slate-600">Technical Architecture & Implementation Details</p>
                </div>
              </div>
              <Button variant="outline" onClick={() => { setShowDocs(false); setUserRole(null); }}>
                Back to Home
              </Button>
            </div>
          </header>
          <SystemArchitecture />
        </div>
        <Toaster />
      </>
    );
  }

  // Doctor dashboard
  if (userRole === "doctor") {
    return (
      <>
        <div className="min-h-screen bg-slate-50">
          <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
            <div className="container mx-auto px-4 py-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Stethoscope className="w-8 h-8 text-blue-600" />
                <div>
                  <h1>NeuroSleep Monitor</h1>
                  <p className="text-sm text-slate-600">Clinician Portal</p>
                </div>
              </div>
              <Button variant="outline" onClick={() => setUserRole(null)}>
                Switch to Patient View
              </Button>
            </div>
          </header>
          <DoctorDashboard />
        </div>
        <Toaster />
      </>
    );
  }

  // Patient onboarding
  if (!hasOnboarded) {
    return (
      <>
        <OnboardingFlow onComplete={handleOnboardingComplete} />
        <Toaster />
      </>
    );
  }

  // Monitoring session
  if (isMonitoring && patientProfile) {
    return (
      <>
        <MonitoringSession
          patientProfile={patientProfile}
          onComplete={handleMonitoringComplete}
          onCancel={() => setIsMonitoring(false)}
        />
        <Toaster />
      </>
    );
  }

  // Patient dashboard
  return (
    <>
      <div className="min-h-screen bg-slate-50">
        <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <UserCircle className="w-8 h-8 text-blue-600" />
              <div>
                <h1>NeuroSleep Monitor</h1>
                <p className="text-sm text-slate-600">Welcome, {patientProfile?.name}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setUserRole("doctor")}>
                View as Doctor
              </Button>
              <Button variant="ghost" size="sm" onClick={handleReset}>
                Reset App
              </Button>
            </div>
          </div>
        </header>
        <PatientDashboard
          patientProfile={patientProfile!}
          monitoringHistory={monitoringHistory}
          onStartMonitoring={() => setIsMonitoring(true)}
        />
      </div>
      <Toaster />
    </>
  );
}

export default App;