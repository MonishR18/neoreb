import { useState, useEffect, useRef } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import {
  Camera,
  Activity,
  AlertTriangle,
  CheckCircle2,
  Moon,
  Wind,
  Heart,
  X,
  Pause,
  Play,
  StopCircle,
} from "lucide-react";
import type { PatientProfile, MonitoringData, Alert } from "../App";
import { toast } from "sonner";
import { BreathingIntervention } from "./BreathingIntervention";

interface MonitoringSessionProps {
  patientProfile: PatientProfile;
  onComplete: (data: MonitoringData) => void;
  onCancel: () => void;
}

export function MonitoringSession({
  patientProfile,
  onComplete,
  onCancel,
}: MonitoringSessionProps) {
  const [stage, setStage] = useState<"setup" | "calibration" | "monitoring" | "intervention">("setup");
  const [cameraReady, setCameraReady] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [breathingRate, setBreathingRate] = useState(16);
  const [breathingRateHistory, setBreathingRateHistory] = useState<number[]>([]);
  const [currentRiskScore, setCurrentRiskScore] = useState(0);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [interventionsUsed, setInterventionsUsed] = useState<string[]>([]);
  const [showIntervention, setShowIntervention] = useState(false);
  const [currentInterventionType, setCurrentInterventionType] = useState<string>("");
  const [calibrationProgress, setCalibrationProgress] = useState(0);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const sessionStartTime = useRef(Date.now());
  const monitoringInterval = useRef<NodeJS.Timeout>();

  // Setup camera
  const setupCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user" },
        audio: false,
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setCameraReady(true);
        toast.success("Camera connected successfully");
      }
    } catch (error) {
      toast.error("Failed to access camera. Please check permissions.");
      console.error("Camera error:", error);
    }
  };

  useEffect(() => {
    if (stage === "setup") {
      setupCamera();
    }
    
    return () => {
      // Cleanup camera stream
      if (videoRef.current && videoRef.current.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
        tracks.forEach(track => track.stop());
      }
      if (monitoringInterval.current) {
        clearInterval(monitoringInterval.current);
      }
    };
  }, [stage]);

  // Calibration
  useEffect(() => {
    if (stage === "calibration") {
      const interval = setInterval(() => {
        setCalibrationProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setStage("monitoring");
            toast.success("Calibration complete. Monitoring started.");
            return 100;
          }
          return prev + 5;
        });
      }, 300);
      
      return () => clearInterval(interval);
    }
  }, [stage]);

  // Monitoring simulation
  useEffect(() => {
    if (stage === "monitoring" && !isPaused) {
      // Timer
      const timer = setInterval(() => {
        setElapsedTime(prev => prev + 1);
      }, 1000);

      // AI monitoring simulation
      monitoringInterval.current = setInterval(() => {
        // Simulate breathing rate detection (12-20 breaths per minute is normal)
        const baseRate = 16;
        const variation = (Math.random() - 0.5) * 6;
        const noise = (Math.random() - 0.5) * 2;
        
        // Occasionally simulate issues based on patient risk level
        let issueModifier = 0;
        const random = Math.random();
        
        if (patientProfile.riskLevel === "high" && random > 0.7) {
          issueModifier = -5; // Shallow breathing
        } else if (patientProfile.riskLevel === "moderate" && random > 0.85) {
          issueModifier = -3;
        }
        
        const newRate = Math.max(8, Math.min(24, baseRate + variation + noise + issueModifier));
        setBreathingRate(newRate);
        setBreathingRateHistory(prev => [...prev, newRate]);

        // Calculate risk score
        let risk = 0;
        if (newRate < 12) risk += 30;
        if (newRate > 20) risk += 20;
        if (newRate < 10) risk += 40;
        
        // Add variability factor
        if (breathingRateHistory.length >= 5) {
          const recentRates = breathingRateHistory.slice(-5);
          const variance = Math.sqrt(
            recentRates.reduce((sum, rate) => sum + Math.pow(rate - newRate, 2), 0) / 5
          );
          if (variance > 3) risk += 20;
        }
        
        setCurrentRiskScore(Math.min(100, risk));

        // Generate alerts based on conditions
        if (newRate < 10 && !alerts.some(a => !a.resolved && a.type === "critical_bradypnea")) {
          const alert: Alert = {
            id: `alert-${Date.now()}`,
            timestamp: new Date().toISOString(),
            severity: "critical",
            type: "critical_bradypnea",
            description: "Critical: Very slow breathing detected (< 10 breaths/min)",
            resolved: false,
          };
          setAlerts(prev => [...prev, alert]);
          toast.error(alert.description);
          
          // Trigger intervention
          setCurrentInterventionType("Anulom Vilom (Alternate Nostril Breathing)");
          setShowIntervention(true);
        } else if (newRate < 12 && !alerts.some(a => !a.resolved && a.type === "shallow_breathing")) {
          const alert: Alert = {
            id: `alert-${Date.now()}`,
            timestamp: new Date().toISOString(),
            severity: "moderate",
            type: "shallow_breathing",
            description: "Moderate: Shallow breathing detected",
            resolved: false,
          };
          setAlerts(prev => [...prev, alert]);
          toast.warning(alert.description);
          
          // Suggest intervention
          setCurrentInterventionType("Diaphragmatic Breathing");
          setShowIntervention(true);
        } else if (newRate > 22 && !alerts.some(a => !a.resolved && a.type === "rapid_breathing")) {
          const alert: Alert = {
            id: `alert-${Date.now()}`,
            timestamp: new Date().toISOString(),
            severity: "moderate",
            type: "rapid_breathing",
            description: "Moderate: Rapid breathing detected",
            resolved: false,
          };
          setAlerts(prev => [...prev, alert]);
          toast.warning(alert.description);
        }
      }, 3000);

      return () => {
        clearInterval(timer);
        if (monitoringInterval.current) {
          clearInterval(monitoringInterval.current);
        }
      };
    }
  }, [stage, isPaused, patientProfile.riskLevel, breathingRateHistory, alerts]);

  const handleStartCalibration = () => {
    setStage("calibration");
    toast.info("Starting calibration. Please remain still and breathe normally.");
  };

  const handlePauseResume = () => {
    setIsPaused(!isPaused);
    toast.info(isPaused ? "Monitoring resumed" : "Monitoring paused");
  };

  const handleInterventionComplete = (interventionName: string) => {
    setInterventionsUsed(prev => [...prev, interventionName]);
    setShowIntervention(false);
    
    // Mark recent alerts as resolved
    setAlerts(prev =>
      prev.map(alert =>
        !alert.resolved
          ? { ...alert, resolved: true, intervention: interventionName }
          : alert
      )
    );
    
    toast.success("Intervention completed. Monitoring resumed.");
  };

  const handleStopMonitoring = () => {
    if (confirm("Are you sure you want to stop monitoring?")) {
      const sessionData: MonitoringData = {
        date: new Date().toISOString(),
        sessionId: `session-${Date.now()}`,
        duration: Math.floor(elapsedTime / 60),
        riskScore: currentRiskScore,
        breathingRate: breathingRateHistory,
        alerts,
        interventionsUsed,
      };
      
      onComplete(sessionData);
      toast.success("Monitoring session completed");
    }
  };

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getRiskColor = (score: number) => {
    if (score < 30) return "text-green-600 bg-green-100";
    if (score < 60) return "text-yellow-600 bg-yellow-100";
    return "text-red-600 bg-red-100";
  };

  return (
    <>
      <div className="min-h-screen bg-slate-900 text-white">
        <header className="bg-slate-800 border-b border-slate-700 p-4">
          <div className="container mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Moon className="w-8 h-8 text-blue-400" />
              <div>
                <h1 className="text-xl">Sleep Monitoring Session</h1>
                <p className="text-sm text-slate-400">
                  {stage === "setup" && "Setting up camera"}
                  {stage === "calibration" && "Calibrating..."}
                  {stage === "monitoring" && `Monitoring - ${formatTime(elapsedTime)}`}
                </p>
              </div>
            </div>
            <Button variant="destructive" onClick={onCancel}>
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
          </div>
        </header>

        <div className="container mx-auto p-4 max-w-7xl">
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Main Video Feed */}
            <div className="lg:col-span-2 space-y-4">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Camera className="w-5 h-5" />
                    Camera Feed
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="relative aspect-video bg-slate-900 rounded-lg overflow-hidden">
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-full object-cover"
                    />
                    
                    {!cameraReady && (
                      <div className="absolute inset-0 flex items-center justify-center bg-slate-900">
                        <div className="text-center">
                          <Camera className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                          <p className="text-slate-400">Connecting to camera...</p>
                        </div>
                      </div>
                    )}

                    {stage === "calibration" && (
                      <div className="absolute inset-0 bg-black bg-opacity-70 flex items-center justify-center">
                        <div className="text-center max-w-md p-8">
                          <Activity className="w-16 h-16 text-blue-400 mx-auto mb-4 animate-pulse" />
                          <h3 className="text-xl mb-2">Calibrating AI Model</h3>
                          <p className="text-slate-300 mb-6">
                            Please remain still and breathe normally while we calibrate the system
                          </p>
                          <Progress value={calibrationProgress} className="h-2" />
                          <p className="text-sm text-slate-400 mt-2">{calibrationProgress}%</p>
                        </div>
                      </div>
                    )}

                    {stage === "monitoring" && (
                      <>
                        {/* Overlay indicators */}
                        <div className="absolute top-4 left-4 right-4 flex justify-between items-start">
                          <Badge className="bg-red-600 text-white animate-pulse">
                            <div className="w-2 h-2 bg-white rounded-full mr-2" />
                            RECORDING
                          </Badge>
                          <Badge className={`${getRiskColor(currentRiskScore)} border-0`}>
                            Risk: {currentRiskScore}
                          </Badge>
                        </div>

                        {/* Breathing visualization */}
                        <div className="absolute bottom-4 left-4 right-4">
                          <div className="bg-slate-900 bg-opacity-90 rounded-lg p-4">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-sm">Breathing Rate</span>
                              <span className="text-2xl font-mono">{breathingRate.toFixed(1)}</span>
                            </div>
                            <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                              <div
                                className="h-full bg-blue-500 transition-all duration-300"
                                style={{ width: `${(breathingRate / 24) * 100}%` }}
                              />
                            </div>
                          </div>
                        </div>
                      </>
                    )}
                  </div>

                  {stage === "setup" && cameraReady && (
                    <div className="mt-4 text-center">
                      <p className="text-slate-400 mb-4">
                        Position the camera to capture your upper body and chest area
                      </p>
                      <Button onClick={handleStartCalibration} size="lg">
                        <CheckCircle2 className="w-5 h-5 mr-2" />
                        Start Calibration
                      </Button>
                    </div>
                  )}

                  {stage === "monitoring" && (
                    <div className="mt-4 flex gap-2 justify-center">
                      <Button
                        variant={isPaused ? "default" : "secondary"}
                        onClick={handlePauseResume}
                      >
                        {isPaused ? (
                          <>
                            <Play className="w-4 h-4 mr-2" />
                            Resume
                          </>
                        ) : (
                          <>
                            <Pause className="w-4 h-4 mr-2" />
                            Pause
                          </>
                        )}
                      </Button>
                      <Button variant="destructive" onClick={handleStopMonitoring}>
                        <StopCircle className="w-4 h-4 mr-2" />
                        Stop Monitoring
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Stats & Alerts Panel */}
            <div className="space-y-4">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white text-base">Live Metrics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-slate-900 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Wind className="w-5 h-5 text-blue-400" />
                      <span className="text-sm">Breathing Rate</span>
                    </div>
                    <span className="text-xl font-mono">{breathingRate.toFixed(1)}</span>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-slate-900 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Activity className="w-5 h-5 text-green-400" />
                      <span className="text-sm">Risk Score</span>
                    </div>
                    <span className={`text-xl font-mono ${getRiskColor(currentRiskScore).split(' ')[0]}`}>
                      {currentRiskScore}
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-slate-900 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Moon className="w-5 h-5 text-purple-400" />
                      <span className="text-sm">Duration</span>
                    </div>
                    <span className="text-xl font-mono">{formatTime(elapsedTime)}</span>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-slate-900 rounded-lg">
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5 text-orange-400" />
                      <span className="text-sm">Alerts</span>
                    </div>
                    <span className="text-xl font-mono">{alerts.length}</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white text-base">Alert History</CardTitle>
                  <CardDescription className="text-slate-400">
                    Recent breathing alerts
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {alerts.length > 0 ? (
                    <div className="space-y-2 max-h-96 overflow-y-auto">
                      {alerts.slice().reverse().map(alert => (
                        <div
                          key={alert.id}
                          className={`p-3 rounded-lg border ${
                            alert.severity === "critical"
                              ? "bg-red-950 border-red-800"
                              : alert.severity === "moderate"
                              ? "bg-yellow-950 border-yellow-800"
                              : "bg-blue-950 border-blue-800"
                          }`}
                        >
                          <div className="flex items-start gap-2">
                            <AlertTriangle
                              className={`w-4 h-4 mt-0.5 ${
                                alert.severity === "critical"
                                  ? "text-red-400"
                                  : alert.severity === "moderate"
                                  ? "text-yellow-400"
                                  : "text-blue-400"
                              }`}
                            />
                            <div className="flex-1 text-sm">
                              <p className="text-white">{alert.description}</p>
                              <p className="text-slate-400 text-xs mt-1">
                                {new Date(alert.timestamp).toLocaleTimeString()}
                              </p>
                              {alert.resolved && (
                                <div className="flex items-center gap-1 mt-2 text-green-400 text-xs">
                                  <CheckCircle2 className="w-3 h-3" />
                                  <span>Resolved{alert.intervention && ` - ${alert.intervention}`}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-slate-400">
                      <CheckCircle2 className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">No alerts yet</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* Breathing Intervention Dialog */}
      <Dialog open={showIntervention} onOpenChange={setShowIntervention}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Guided Breathing Intervention</DialogTitle>
            <DialogDescription>
              An irregular breathing pattern was detected. Follow this guided exercise to help regulate your breathing.
            </DialogDescription>
          </DialogHeader>
          <BreathingIntervention
            interventionType={currentInterventionType}
            onComplete={handleInterventionComplete}
            onSkip={() => setShowIntervention(false)}
          />
        </DialogContent>
      </Dialog>
    </>
  );
}
