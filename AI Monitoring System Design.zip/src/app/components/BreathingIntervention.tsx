import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Progress } from "./ui/progress";
import { Wind, Circle, Play, Pause, CheckCircle2, SkipForward } from "lucide-react";

interface BreathingInterventionProps {
  interventionType: string;
  onComplete: (interventionName: string) => void;
  onSkip: () => void;
}

const INTERVENTIONS = {
  "Anulom Vilom (Alternate Nostril Breathing)": {
    description: "Helps balance the nervous system and improve oxygen flow",
    duration: 180, // 3 minutes
    phases: [
      { name: "Close right nostril, inhale left", duration: 4 },
      { name: "Close both, hold", duration: 4 },
      { name: "Close left nostril, exhale right", duration: 4 },
      { name: "Inhale right", duration: 4 },
      { name: "Close both, hold", duration: 4 },
      { name: "Close right nostril, exhale left", duration: 4 },
    ],
    instructions: [
      "Sit comfortably with spine straight",
      "Place left hand on left knee",
      "Use right thumb to close right nostril",
      "Use right ring finger to close left nostril",
      "Follow the breathing pattern shown",
    ],
  },
  "Diaphragmatic Breathing": {
    description: "Strengthens the diaphragm and promotes deeper breathing",
    duration: 120, // 2 minutes
    phases: [
      { name: "Inhale deeply through nose", duration: 4 },
      { name: "Hold", duration: 2 },
      { name: "Exhale slowly through mouth", duration: 6 },
      { name: "Rest", duration: 2 },
    ],
    instructions: [
      "Lie on your back or sit comfortably",
      "Place one hand on chest, other on belly",
      "Breathe so that belly rises more than chest",
      "Focus on slow, deep breaths",
      "Relax your shoulders",
    ],
  },
  "Bhramari (Bee Breath)": {
    description: "Calms the mind and reduces anxiety, improving breathing patterns",
    duration: 120,
    phases: [
      { name: "Deep inhale through nose", duration: 4 },
      { name: "Hum while exhaling (like a bee)", duration: 6 },
      { name: "Rest", duration: 3 },
    ],
    instructions: [
      "Sit in a comfortable position",
      "Close your eyes gently",
      "Place index fingers on ears",
      "Inhale deeply through nose",
      "While exhaling, make a humming sound",
    ],
  },
};

export function BreathingIntervention({
  interventionType,
  onComplete,
  onSkip,
}: BreathingInterventionProps) {
  const intervention = INTERVENTIONS[interventionType as keyof typeof INTERVENTIONS] || INTERVENTIONS["Diaphragmatic Breathing"];
  
  const [isActive, setIsActive] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(intervention.duration);
  const [currentPhaseIndex, setCurrentPhaseIndex] = useState(0);
  const [phaseTimeRemaining, setPhaseTimeRemaining] = useState(intervention.phases[0].duration);
  const [cyclesCompleted, setCompletesCompleted] = useState(0);

  const currentPhase = intervention.phases[currentPhaseIndex];
  const progress = ((intervention.duration - timeRemaining) / intervention.duration) * 100;
  const phaseProgress = ((currentPhase.duration - phaseTimeRemaining) / currentPhase.duration) * 100;

  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(() => {
      setPhaseTimeRemaining(prev => {
        if (prev <= 1) {
          // Move to next phase
          const nextIndex = (currentPhaseIndex + 1) % intervention.phases.length;
          setCurrentPhaseIndex(nextIndex);
          
          if (nextIndex === 0) {
            setCompletesCompleted(prev => prev + 1);
          }
          
          return intervention.phases[nextIndex].duration;
        }
        return prev - 1;
      });

      setTimeRemaining(prev => {
        if (prev <= 1) {
          setIsActive(false);
          onComplete(interventionType);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isActive, currentPhaseIndex, intervention.phases, interventionType, onComplete]);

  const handleStart = () => {
    setIsActive(true);
  };

  const handlePause = () => {
    setIsActive(false);
  };

  const handleComplete = () => {
    onComplete(interventionType);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getBreathingCircleScale = () => {
    const normalizedProgress = phaseProgress / 100;
    
    if (currentPhase.name.toLowerCase().includes("inhale")) {
      // Expand during inhale
      return 0.5 + (normalizedProgress * 0.5);
    } else if (currentPhase.name.toLowerCase().includes("exhale")) {
      // Shrink during exhale
      return 1 - (normalizedProgress * 0.5);
    } else {
      // Hold steady
      return currentPhase.name.toLowerCase().includes("hold") ? 1 : 0.75;
    }
  };

  return (
    <div className="space-y-6">
      {/* Instructions */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3 mb-4">
            <Wind className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-medium text-blue-900 mb-1">{interventionType}</h3>
              <p className="text-sm text-blue-700">{intervention.description}</p>
            </div>
          </div>
          <div className="space-y-2">
            <p className="text-sm font-medium text-blue-900">Instructions:</p>
            <ol className="list-decimal list-inside space-y-1 text-sm text-blue-700">
              {intervention.instructions.map((instruction, idx) => (
                <li key={idx}>{instruction}</li>
              ))}
            </ol>
          </div>
        </CardContent>
      </Card>

      {/* Main Breathing Visualizer */}
      <div className="relative">
        <div className="aspect-square max-w-md mx-auto bg-gradient-to-br from-blue-50 to-indigo-50 rounded-full flex items-center justify-center p-12">
          <div
            className="relative w-full h-full flex items-center justify-center transition-transform duration-1000 ease-in-out"
            style={{ transform: `scale(${getBreathingCircleScale()})` }}
          >
            <div className="absolute inset-0 bg-blue-400 rounded-full opacity-20 animate-pulse" />
            <div className="absolute inset-4 bg-blue-500 rounded-full opacity-30" />
            <div className="absolute inset-8 bg-blue-600 rounded-full opacity-40 flex items-center justify-center">
              <div className="text-center text-white">
                <Circle className="w-16 h-16 mx-auto mb-4" />
                <p className="text-2xl font-medium mb-2">{currentPhase.name}</p>
                <p className="text-4xl font-mono">{phaseTimeRemaining}s</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Progress */}
      <div className="space-y-4">
        <div>
          <div className="flex justify-between text-sm mb-2">
            <span>Overall Progress</span>
            <span>{formatTime(timeRemaining)} remaining</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        <div className="grid grid-cols-3 gap-4 text-center">
          <div className="p-3 bg-slate-50 rounded-lg">
            <p className="text-sm text-slate-600">Duration</p>
            <p className="text-xl font-medium">{intervention.duration / 60} min</p>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg">
            <p className="text-sm text-slate-600">Cycles Done</p>
            <p className="text-xl font-medium">{cyclesCompleted}</p>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg">
            <p className="text-sm text-slate-600">Phase</p>
            <p className="text-xl font-medium">{currentPhaseIndex + 1}/{intervention.phases.length}</p>
          </div>
        </div>
      </div>

      {/* Phase Indicators */}
      <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
        {intervention.phases.map((phase, idx) => (
          <div
            key={idx}
            className={`p-2 rounded text-center text-xs transition-colors ${
              idx === currentPhaseIndex
                ? "bg-blue-600 text-white"
                : idx < currentPhaseIndex
                ? "bg-green-100 text-green-800"
                : "bg-slate-100 text-slate-600"
            }`}
          >
            {phase.name.split(" ").slice(0, 2).join(" ")}
          </div>
        ))}
      </div>

      {/* Controls */}
      <div className="flex gap-3 justify-center pt-4 border-t">
        {!isActive && timeRemaining === intervention.duration ? (
          <Button size="lg" onClick={handleStart} className="min-w-32">
            <Play className="w-5 h-5 mr-2" />
            Start
          </Button>
        ) : !isActive && timeRemaining > 0 ? (
          <>
            <Button size="lg" onClick={handleStart} className="min-w-32">
              <Play className="w-5 h-5 mr-2" />
              Resume
            </Button>
            <Button size="lg" variant="secondary" onClick={handleComplete} className="min-w-32">
              <CheckCircle2 className="w-5 h-5 mr-2" />
              Done
            </Button>
          </>
        ) : isActive ? (
          <Button size="lg" variant="secondary" onClick={handlePause} className="min-w-32">
            <Pause className="w-5 h-5 mr-2" />
            Pause
          </Button>
        ) : null}
        
        <Button size="lg" variant="outline" onClick={onSkip}>
          <SkipForward className="w-5 h-5 mr-2" />
          Skip
        </Button>
      </div>
    </div>
  );
}
