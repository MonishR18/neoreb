import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { RadioGroup, RadioGroupItem } from "./ui/radio-group";
import { Checkbox } from "./ui/checkbox";
import { Progress } from "./ui/progress";
import { Textarea } from "./ui/textarea";
import { ArrowRight, ArrowLeft, CheckCircle2 } from "lucide-react";
import type { PatientProfile } from "../App";

interface OnboardingFlowProps {
  onComplete: (profile: PatientProfile) => void;
}

export function OnboardingFlow({ onComplete }: OnboardingFlowProps) {
  const [step, setStep] = useState(1);
  const totalSteps = 4;

  // Step 1: Basic Information
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [diagnosisDate, setDiagnosisDate] = useState("");

  // Step 2: Medication & Treatment
  const [medications, setMedications] = useState<string[]>([]);
  const [otherMeds, setOtherMeds] = useState("");

  // Step 3: Baseline Questionnaire
  const [sleepQuality, setSleepQuality] = useState("");
  const [breathingIssues, setBreathingIssues] = useState("");
  const [nighttimeSymptoms, setNighttimeSymptoms] = useState<string[]>([]);
  const [fallFrequency, setFallFrequency] = useState("");
  const [motorSymptomSeverity, setMotorSymptomSeverity] = useState("");

  // Step 4: Consent & Privacy
  const [consents, setConsents] = useState({
    dataCollection: false,
    cameraUsage: false,
    healthSharing: false,
    termsOfUse: false,
  });

  const progress = (step / totalSteps) * 100;

  const handleMedicationToggle = (med: string) => {
    setMedications(prev =>
      prev.includes(med) ? prev.filter(m => m !== med) : [...prev, med]
    );
  };

  const handleSymptomToggle = (symptom: string) => {
    setNighttimeSymptoms(prev =>
      prev.includes(symptom) ? prev.filter(s => s !== symptom) : [...prev, symptom]
    );
  };

  const handleComplete = () => {
    // Calculate initial risk level based on responses
    let riskScore = 0;
    if (parseInt(sleepQuality) <= 2) riskScore += 2;
    if (breathingIssues === "frequently" || breathingIssues === "always") riskScore += 3;
    if (nighttimeSymptoms.length >= 3) riskScore += 2;
    if (fallFrequency === "weekly" || fallFrequency === "daily") riskScore += 2;
    if (motorSymptomSeverity === "severe") riskScore += 2;

    const riskLevel = riskScore <= 3 ? "low" : riskScore <= 7 ? "moderate" : "high";

    const profile: PatientProfile = {
      name,
      age: parseInt(age),
      diagnosisDate,
      medicationSchedule: [...medications, ...(otherMeds ? [otherMeds] : [])],
      baselineQuestionnaire: {
        sleepQuality: parseInt(sleepQuality),
        breathingIssues,
        nighttimeSymptoms,
        fallFrequency,
        motorSymptomSeverity,
      },
      riskLevel,
    };

    onComplete(profile);
  };

  const canProceed = () => {
    switch (step) {
      case 1:
        return name.trim() && age && diagnosisDate;
      case 2:
        return medications.length > 0 || otherMeds.trim();
      case 3:
        return sleepQuality && breathingIssues && fallFrequency && motorSymptomSeverity;
      case 4:
        return Object.values(consents).every(v => v);
      default:
        return false;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center p-4">
      <div className="max-w-3xl w-full">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-sm text-slate-600">Step {step} of {totalSteps}</h2>
            <span className="text-sm text-slate-600">{Math.round(progress)}% Complete</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {step === 1 && (
          <Card>
            <CardHeader>
              <CardTitle>Welcome! Let's get to know you</CardTitle>
              <CardDescription>
                This information helps us personalize your monitoring experience
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter your full name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="age">Age</Label>
                <Input
                  id="age"
                  type="number"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  placeholder="Enter your age"
                  min="18"
                  max="120"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="diagnosisDate">When were you diagnosed with Parkinson's?</Label>
                <Input
                  id="diagnosisDate"
                  type="date"
                  value={diagnosisDate}
                  onChange={(e) => setDiagnosisDate(e.target.value)}
                />
              </div>
            </CardContent>
          </Card>
        )}

        {step === 2 && (
          <Card>
            <CardHeader>
              <CardTitle>Medication & Treatment</CardTitle>
              <CardDescription>
                Select all medications you currently take for Parkinson's
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                {["Levodopa/Carbidopa", "Dopamine Agonists", "MAO-B Inhibitors", "COMT Inhibitors", "Amantadine"].map((med) => (
                  <div key={med} className="flex items-center space-x-2">
                    <Checkbox
                      id={med}
                      checked={medications.includes(med)}
                      onCheckedChange={() => handleMedicationToggle(med)}
                    />
                    <Label htmlFor={med} className="cursor-pointer">
                      {med}
                    </Label>
                  </div>
                ))}
              </div>

              <div className="space-y-2">
                <Label htmlFor="otherMeds">Other medications or supplements</Label>
                <Textarea
                  id="otherMeds"
                  value={otherMeds}
                  onChange={(e) => setOtherMeds(e.target.value)}
                  placeholder="List any other medications, supplements, or treatments..."
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
        )}

        {step === 3 && (
          <Card>
            <CardHeader>
              <CardTitle>Baseline Health Assessment</CardTitle>
              <CardDescription>
                This helps us understand your current condition and personalize your monitoring
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label>How would you rate your sleep quality? (1 = Poor, 5 = Excellent)</Label>
                <RadioGroup value={sleepQuality} onValueChange={setSleepQuality}>
                  <div className="flex gap-4">
                    {[1, 2, 3, 4, 5].map((rating) => (
                      <div key={rating} className="flex items-center space-x-2">
                        <RadioGroupItem value={rating.toString()} id={`sleep-${rating}`} />
                        <Label htmlFor={`sleep-${rating}`} className="cursor-pointer">
                          {rating}
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label>Do you experience breathing difficulties during sleep?</Label>
                <RadioGroup value={breathingIssues} onValueChange={setBreathingIssues}>
                  {["never", "rarely", "sometimes", "frequently", "always"].map((freq) => (
                    <div key={freq} className="flex items-center space-x-2">
                      <RadioGroupItem value={freq} id={`breathing-${freq}`} />
                      <Label htmlFor={`breathing-${freq}`} className="cursor-pointer capitalize">
                        {freq}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label>Which nighttime symptoms do you experience? (Select all that apply)</Label>
                <div className="space-y-2">
                  {["Difficulty turning in bed", "Nightmares/vivid dreams", "Restless legs", "Tremors", "Muscle stiffness", "Frequent urination"].map((symptom) => (
                    <div key={symptom} className="flex items-center space-x-2">
                      <Checkbox
                        id={symptom}
                        checked={nighttimeSymptoms.includes(symptom)}
                        onCheckedChange={() => handleSymptomToggle(symptom)}
                      />
                      <Label htmlFor={symptom} className="cursor-pointer">
                        {symptom}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>How often do you experience falls or near-falls?</Label>
                <RadioGroup value={fallFrequency} onValueChange={setFallFrequency}>
                  {["never", "monthly", "weekly", "daily"].map((freq) => (
                    <div key={freq} className="flex items-center space-x-2">
                      <RadioGroupItem value={freq} id={`falls-${freq}`} />
                      <Label htmlFor={`falls-${freq}`} className="cursor-pointer capitalize">
                        {freq}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label>Overall motor symptom severity</Label>
                <RadioGroup value={motorSymptomSeverity} onValueChange={setMotorSymptomSeverity}>
                  {["mild", "moderate", "severe"].map((severity) => (
                    <div key={severity} className="flex items-center space-x-2">
                      <RadioGroupItem value={severity} id={`motor-${severity}`} />
                      <Label htmlFor={`motor-${severity}`} className="cursor-pointer capitalize">
                        {severity}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>
            </CardContent>
          </Card>
        )}

        {step === 4 && (
          <Card>
            <CardHeader>
              <CardTitle>Privacy & Consent</CardTitle>
              <CardDescription>
                Please review and accept our privacy practices
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-2 text-sm">
                <p className="font-medium">Our Privacy Commitments:</p>
                <ul className="list-disc list-inside space-y-1 text-slate-700">
                  <li>No continuous video storage - only real-time analysis</li>
                  <li>All data is encrypted end-to-end</li>
                  <li>You control who sees your data</li>
                  <li>Data can be deleted at any time</li>
                  <li>Not intended for collecting PII or securing sensitive data</li>
                </ul>
              </div>

              <div className="space-y-4">
                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="dataCollection"
                    checked={consents.dataCollection}
                    onCheckedChange={(checked) =>
                      setConsents(prev => ({ ...prev, dataCollection: checked as boolean }))
                    }
                  />
                  <Label htmlFor="dataCollection" className="cursor-pointer leading-tight">
                    I consent to the collection and processing of my health data for monitoring purposes
                  </Label>
                </div>

                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="cameraUsage"
                    checked={consents.cameraUsage}
                    onCheckedChange={(checked) =>
                      setConsents(prev => ({ ...prev, cameraUsage: checked as boolean }))
                    }
                  />
                  <Label htmlFor="cameraUsage" className="cursor-pointer leading-tight">
                    I consent to camera-based monitoring during sleep. I understand that video is processed in real-time and not stored.
                  </Label>
                </div>

                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="healthSharing"
                    checked={consents.healthSharing}
                    onCheckedChange={(checked) =>
                      setConsents(prev => ({ ...prev, healthSharing: checked as boolean }))
                    }
                  />
                  <Label htmlFor="healthSharing" className="cursor-pointer leading-tight">
                    I consent to sharing my monitoring data with my healthcare provider
                  </Label>
                </div>

                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="termsOfUse"
                    checked={consents.termsOfUse}
                    onCheckedChange={(checked) =>
                      setConsents(prev => ({ ...prev, termsOfUse: checked as boolean }))
                    }
                  />
                  <Label htmlFor="termsOfUse" className="cursor-pointer leading-tight">
                    I agree to the Terms of Use and understand this is a monitoring tool, not a diagnostic medical device
                  </Label>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="flex justify-between mt-8">
          <Button
            variant="outline"
            onClick={() => setStep(step - 1)}
            disabled={step === 1}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>

          {step < totalSteps ? (
            <Button
              onClick={() => setStep(step + 1)}
              disabled={!canProceed()}
            >
              Continue
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          ) : (
            <Button
              onClick={handleComplete}
              disabled={!canProceed()}
              className="bg-green-600 hover:bg-green-700"
            >
              <CheckCircle2 className="w-4 h-4 mr-2" />
              Complete Setup
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
