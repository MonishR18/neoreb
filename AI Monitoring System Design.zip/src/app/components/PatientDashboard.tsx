import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Progress } from "./ui/progress";
import {
  Activity,
  Moon,
  AlertTriangle,
  TrendingUp,
  Calendar,
  Play,
  FileText,
  Settings,
  Wind,
  Heart,
  Clock,
  CheckCircle2,
  XCircle,
} from "lucide-react";
import type { PatientProfile, MonitoringData } from "../App";
import { LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { format } from "date-fns";

interface PatientDashboardProps {
  patientProfile: PatientProfile;
  monitoringHistory: MonitoringData[];
  onStartMonitoring: () => void;
}

export function PatientDashboard({
  patientProfile,
  monitoringHistory,
  onStartMonitoring,
}: PatientDashboardProps) {
  const [selectedPeriod, setSelectedPeriod] = useState<"week" | "month" | "all">("week");

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "low":
        return "bg-green-100 text-green-800";
      case "moderate":
        return "bg-yellow-100 text-yellow-800";
      case "high":
        return "bg-red-100 text-red-800";
      default:
        return "bg-slate-100 text-slate-800";
    }
  };

  const getAlertStats = () => {
    const allAlerts = monitoringHistory.flatMap(m => m.alerts);
    return {
      total: allAlerts.length,
      critical: allAlerts.filter(a => a.severity === "critical").length,
      moderate: allAlerts.filter(a => a.severity === "moderate").length,
      low: allAlerts.filter(a => a.severity === "low").length,
      resolved: allAlerts.filter(a => a.resolved).length,
    };
  };

  const getAverageBreathingRate = () => {
    if (monitoringHistory.length === 0) return 0;
    const allRates = monitoringHistory.flatMap(m => m.breathingRate);
    return (allRates.reduce((a, b) => a + b, 0) / allRates.length).toFixed(1);
  };

  const getTotalMonitoringHours = () => {
    const totalMinutes = monitoringHistory.reduce((sum, m) => sum + m.duration, 0);
    return (totalMinutes / 60).toFixed(1);
  };

  // Chart data
  const riskTrendData = monitoringHistory.slice(0, 14).reverse().map(m => ({
    date: format(new Date(m.date), "MM/dd"),
    riskScore: m.riskScore,
  }));

  const breathingRateData = monitoringHistory.slice(0, 7).reverse().map(m => ({
    date: format(new Date(m.date), "MM/dd"),
    avgRate: (m.breathingRate.reduce((a, b) => a + b, 0) / m.breathingRate.length).toFixed(1),
    minRate: Math.min(...m.breathingRate),
    maxRate: Math.max(...m.breathingRate),
  }));

  const alertStats = getAlertStats();

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      {/* Hero Section */}
      <div className="mb-8">
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="md:col-span-2 bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-2xl mb-2">Ready for tonight's monitoring?</CardTitle>
                  <CardDescription className="text-base">
                    Position your camera and start your sleep session
                  </CardDescription>
                </div>
                <Moon className="w-16 h-16 text-blue-600 opacity-20" />
              </div>
            </CardHeader>
            <CardContent>
              <Button size="lg" onClick={onStartMonitoring} className="w-full md:w-auto">
                <Play className="w-5 h-5 mr-2" />
                Start Monitoring Session
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Current Risk Level</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <Badge className={`${getRiskColor(patientProfile.riskLevel)} text-lg px-4 py-2 capitalize`}>
                  {patientProfile.riskLevel}
                </Badge>
                <p className="text-sm text-slate-600 mt-4">
                  Based on your baseline assessment and recent monitoring data
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total Sessions</p>
                <p className="text-2xl mt-1">{monitoringHistory.length}</p>
              </div>
              <Calendar className="w-8 h-8 text-blue-600 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total Hours</p>
                <p className="text-2xl mt-1">{getTotalMonitoringHours()}</p>
              </div>
              <Clock className="w-8 h-8 text-indigo-600 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Avg Breathing</p>
                <p className="text-2xl mt-1">{getAverageBreathingRate()}</p>
                <p className="text-xs text-slate-500">breaths/min</p>
              </div>
              <Wind className="w-8 h-8 text-green-600 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total Alerts</p>
                <p className="text-2xl mt-1">{alertStats.total}</p>
                <p className="text-xs text-slate-500">{alertStats.resolved} resolved</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-orange-600 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
          <TabsTrigger value="profile">Profile</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Risk Score Trend (Last 14 Days)</CardTitle>
                <CardDescription>Lower scores indicate better breathing patterns</CardDescription>
              </CardHeader>
              <CardContent>
                {riskTrendData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={250}>
                    <AreaChart data={riskTrendData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis domain={[0, 100]} />
                      <Tooltip />
                      <Area type="monotone" dataKey="riskScore" stroke="#3b82f6" fill="#93c5fd" />
                    </AreaChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-64 flex items-center justify-center text-slate-400">
                    No monitoring data yet. Start your first session!
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Alert Distribution</CardTitle>
                <CardDescription>Breakdown of alerts by severity</CardDescription>
              </CardHeader>
              <CardContent>
                {alertStats.total > 0 ? (
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-red-600">Critical</span>
                        <span>{alertStats.critical}</span>
                      </div>
                      <Progress value={(alertStats.critical / alertStats.total) * 100} className="h-2 bg-red-100" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-yellow-600">Moderate</span>
                        <span>{alertStats.moderate}</span>
                      </div>
                      <Progress value={(alertStats.moderate / alertStats.total) * 100} className="h-2 bg-yellow-100" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-blue-600">Low</span>
                        <span>{alertStats.low}</span>
                      </div>
                      <Progress value={(alertStats.low / alertStats.total) * 100} className="h-2 bg-blue-100" />
                    </div>
                    <div className="pt-4 border-t">
                      <div className="flex justify-between text-sm">
                        <span className="text-green-600">Resolved</span>
                        <span>{alertStats.resolved} / {alertStats.total}</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="h-64 flex items-center justify-center text-slate-400">
                    No alerts recorded yet
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Recent Interventions Used</CardTitle>
              <CardDescription>Breathing exercises that helped during monitoring</CardDescription>
            </CardHeader>
            <CardContent>
              {monitoringHistory.length > 0 ? (
                <div className="space-y-2">
                  {monitoringHistory
                    .slice(0, 5)
                    .flatMap(m => m.interventionsUsed)
                    .filter((v, i, a) => a.indexOf(v) === i)
                    .map((intervention, idx) => (
                      <div key={idx} className="flex items-center gap-2 p-3 bg-blue-50 rounded-lg">
                        <Wind className="w-5 h-5 text-blue-600" />
                        <span>{intervention}</span>
                      </div>
                    ))}
                </div>
              ) : (
                <div className="text-center text-slate-400 py-8">
                  No interventions used yet
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Monitoring History</CardTitle>
              <CardDescription>Complete record of your sleep monitoring sessions</CardDescription>
            </CardHeader>
            <CardContent>
              {monitoringHistory.length > 0 ? (
                <div className="space-y-4">
                  {monitoringHistory.map((session) => (
                    <div key={session.sessionId} className="border rounded-lg p-4 hover:bg-slate-50 transition">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <p className="font-medium">{format(new Date(session.date), "MMMM dd, yyyy")}</p>
                          <p className="text-sm text-slate-600">
                            Duration: {session.duration} minutes
                          </p>
                        </div>
                        <Badge
                          className={
                            session.riskScore < 30
                              ? "bg-green-100 text-green-800"
                              : session.riskScore < 60
                              ? "bg-yellow-100 text-yellow-800"
                              : "bg-red-100 text-red-800"
                          }
                        >
                          Risk Score: {session.riskScore}
                        </Badge>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-slate-600">Avg Breathing</p>
                          <p className="font-medium">
                            {(session.breathingRate.reduce((a, b) => a + b, 0) / session.breathingRate.length).toFixed(1)} bpm
                          </p>
                        </div>
                        <div>
                          <p className="text-slate-600">Alerts</p>
                          <p className="font-medium">{session.alerts.length}</p>
                        </div>
                        <div>
                          <p className="text-slate-600">Interventions</p>
                          <p className="font-medium">{session.interventionsUsed.length}</p>
                        </div>
                        <div>
                          <p className="text-slate-600">Status</p>
                          <p className="font-medium text-green-600">Completed</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 text-slate-400">
                  <Moon className="w-16 h-16 mx-auto mb-4 opacity-50" />
                  <p>No monitoring sessions yet</p>
                  <p className="text-sm">Start your first session to see your history here</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Breathing Rate Trends (Last 7 Days)</CardTitle>
              <CardDescription>Track your breathing patterns over time</CardDescription>
            </CardHeader>
            <CardContent>
              {breathingRateData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={breathingRateData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis domain={[0, 30]} />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="avgRate" stroke="#3b82f6" name="Average" strokeWidth={2} />
                    <Line type="monotone" dataKey="minRate" stroke="#10b981" name="Min" strokeDasharray="5 5" />
                    <Line type="monotone" dataKey="maxRate" stroke="#f59e0b" name="Max" strokeDasharray="5 5" />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-72 flex items-center justify-center text-slate-400">
                  Insufficient data for trend analysis
                </div>
              )}
            </CardContent>
          </Card>

          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Weekly Summary</CardTitle>
                <CardDescription>Your performance this week</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Sessions Completed</span>
                  <span className="font-medium">{monitoringHistory.filter(m => new Date(m.date) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)).length}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Avg Risk Score</span>
                  <span className="font-medium">
                    {monitoringHistory.length > 0
                      ? (monitoringHistory.slice(0, 7).reduce((sum, m) => sum + m.riskScore, 0) / Math.min(7, monitoringHistory.length)).toFixed(0)
                      : "N/A"}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Critical Alerts</span>
                  <span className="font-medium text-red-600">
                    {monitoringHistory
                      .filter(m => new Date(m.date) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000))
                      .flatMap(m => m.alerts)
                      .filter(a => a.severity === "critical").length}
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recommendations</CardTitle>
                <CardDescription>Based on your recent data</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {monitoringHistory.length < 7 && (
                  <div className="flex gap-2 p-3 bg-blue-50 rounded-lg text-sm">
                    <Activity className="w-5 h-5 text-blue-600 flex-shrink-0" />
                    <span>Complete more monitoring sessions for better insights</span>
                  </div>
                )}
                {alertStats.critical > 5 && (
                  <div className="flex gap-2 p-3 bg-red-50 rounded-lg text-sm">
                    <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0" />
                    <span>You've had multiple critical alerts. Consider consulting your doctor.</span>
                  </div>
                )}
                <div className="flex gap-2 p-3 bg-green-50 rounded-lg text-sm">
                  <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span>Practice breathing exercises daily for best results</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="profile" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Patient Profile</CardTitle>
              <CardDescription>Your personal information and baseline assessment</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label className="text-sm text-slate-600">Name</Label>
                  <p className="font-medium mt-1">{patientProfile.name}</p>
                </div>
                <div>
                  <Label className="text-sm text-slate-600">Age</Label>
                  <p className="font-medium mt-1">{patientProfile.age} years</p>
                </div>
                <div>
                  <Label className="text-sm text-slate-600">Diagnosis Date</Label>
                  <p className="font-medium mt-1">{format(new Date(patientProfile.diagnosisDate), "MMMM dd, yyyy")}</p>
                </div>
                <div>
                  <Label className="text-sm text-slate-600">Current Risk Level</Label>
                  <Badge className={`${getRiskColor(patientProfile.riskLevel)} mt-1 capitalize`}>
                    {patientProfile.riskLevel}
                  </Badge>
                </div>
              </div>

              <div>
                <Label className="text-sm text-slate-600">Medications</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {patientProfile.medicationSchedule.map((med, idx) => (
                    <Badge key={idx} variant="outline">
                      {med}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-sm text-slate-600 mb-3 block">Baseline Assessment</Label>
                <div className="grid md:grid-cols-2 gap-4 text-sm">
                  <div className="p-3 bg-slate-50 rounded-lg">
                    <p className="text-slate-600">Sleep Quality</p>
                    <p className="font-medium mt-1">{patientProfile.baselineQuestionnaire.sleepQuality}/5</p>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg">
                    <p className="text-slate-600">Breathing Issues</p>
                    <p className="font-medium mt-1 capitalize">{patientProfile.baselineQuestionnaire.breathingIssues}</p>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg">
                    <p className="text-slate-600">Fall Frequency</p>
                    <p className="font-medium mt-1 capitalize">{patientProfile.baselineQuestionnaire.fallFrequency}</p>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg">
                    <p className="text-slate-600">Motor Symptoms</p>
                    <p className="font-medium mt-1 capitalize">{patientProfile.baselineQuestionnaire.motorSymptomSeverity}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function Label({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <div className={className}>{children}</div>;
}
