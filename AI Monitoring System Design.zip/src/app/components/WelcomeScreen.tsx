import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { UserCircle, Stethoscope, Brain, Activity, Shield, Moon } from "lucide-react";
import type { UserRole } from "../App";

interface WelcomeScreenProps {
  onSelectRole: (role: UserRole) => void;
}

export function WelcomeScreen({ onSelectRole }: WelcomeScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center p-4">
      <div className="max-w-6xl w-full">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Brain className="w-12 h-12 text-blue-600" />
            <h1 className="text-5xl">NeuroSleep Monitor</h1>
          </div>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            AI-Powered Sleep Breathing Monitoring for Parkinson's Patients
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-12">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer border-2 hover:border-blue-500"
                onClick={() => onSelectRole("patient")}>
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
                <UserCircle className="w-10 h-10 text-blue-600" />
              </div>
              <CardTitle>I'm a Patient</CardTitle>
              <CardDescription>
                Monitor your sleep breathing patterns and receive personalized interventions
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <Activity className="w-4 h-4 text-green-600" />
                <span>Real-time breathing monitoring</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <Moon className="w-4 h-4 text-purple-600" />
                <span>Personalized sleep tracking</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <Shield className="w-4 h-4 text-blue-600" />
                <span>Privacy-first design</span>
              </div>
              <Button className="w-full mt-4" onClick={() => onSelectRole("patient")}>
                Get Started as Patient
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow cursor-pointer border-2 hover:border-indigo-500"
                onClick={() => onSelectRole("doctor")}>
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center">
                <Stethoscope className="w-10 h-10 text-indigo-600" />
              </div>
              <CardTitle>I'm a Clinician</CardTitle>
              <CardDescription>
                Access patient analytics, trends, and comprehensive monitoring reports
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <Activity className="w-4 h-4 text-green-600" />
                <span>Patient trend analysis</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <Moon className="w-4 h-4 text-purple-600" />
                <span>Detailed sleep reports</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <Shield className="w-4 h-4 text-blue-600" />
                <span>Clinical insights dashboard</span>
              </div>
              <Button className="w-full mt-4" variant="secondary" onClick={() => onSelectRole("doctor")}>
                Access Clinician Portal
              </Button>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-center">How It Works</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-3">
                  1
                </div>
                <p className="text-sm">
                  Complete initial questionnaire
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-3">
                  2
                </div>
                <p className="text-sm">
                  Position camera to monitor breathing
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-3">
                  3
                </div>
                <p className="text-sm">
                  AI analyzes breathing patterns during sleep
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-3">
                  4
                </div>
                <p className="text-sm">
                  Receive alerts and guided interventions
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="mt-8 text-center text-sm text-slate-500">
          <p>
            <Shield className="w-4 h-4 inline mr-1" />
            This is a monitoring tool, not a diagnostic device. Always consult your healthcare provider.
          </p>
          <p className="mt-2">Privacy-first • No video storage • Encrypted data • Consent-driven</p>
        </div>
      </div>
    </div>
  );
}
