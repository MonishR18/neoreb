import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import {
  Users,
  TrendingDown,
  TrendingUp,
  Activity,
  AlertTriangle,
  FileText,
  Download,
  Search,
  Calendar,
  Clock,
  Moon,
  Heart,
  Wind,
} from "lucide-react";
import { LineChart, Line, BarChart, Bar, AreaChart, Area, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

// Mock patient data
const MOCK_PATIENTS = [
  {
    id: "P001",
    name: "Rajesh Kumar",
    age: 68,
    riskLevel: "high" as const,
    lastSession: "2024-12-17",
    totalSessions: 45,
    avgRiskScore: 72,
    criticalAlerts: 8,
    trend: "improving",
  },
  {
    id: "P002",
    name: "Anita Sharma",
    age: 62,
    riskLevel: "moderate" as const,
    lastSession: "2024-12-18",
    totalSessions: 32,
    avgRiskScore: 48,
    criticalAlerts: 2,
    trend: "stable",
  },
  {
    id: "P003",
    name: "Suresh Patel",
    age: 71,
    riskLevel: "low" as const,
    lastSession: "2024-12-18",
    totalSessions: 28,
    avgRiskScore: 25,
    criticalAlerts: 0,
    trend: "improving",
  },
  {
    id: "P004",
    name: "Meera Reddy",
    age: 65,
    riskLevel: "high" as const,
    lastSession: "2024-12-16",
    totalSessions: 51,
    avgRiskScore: 78,
    criticalAlerts: 12,
    trend: "declining",
  },
  {
    id: "P005",
    name: "Vijay Singh",
    age: 59,
    riskLevel: "moderate" as const,
    lastSession: "2024-12-18",
    totalSessions: 19,
    avgRiskScore: 52,
    criticalAlerts: 3,
    trend: "stable",
  },
];

export function DoctorDashboard() {
  const [selectedPatient, setSelectedPatient] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterRisk, setFilterRisk] = useState<string>("all");

  const filteredPatients = MOCK_PATIENTS.filter(patient => {
    const matchesSearch = patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         patient.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRisk = filterRisk === "all" || patient.riskLevel === filterRisk;
    return matchesSearch && matchesRisk;
  });

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "low":
        return "bg-green-100 text-green-800";
      case "moderate":
        return "bg-yellow-100 text-yellow-800";
      case "high":
        return "bg-red-100 text-red-800";
      default:
        return "bg-slate-100 text-slate-800";
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "improving":
        return <TrendingDown className="w-4 h-4 text-green-600" />;
      case "declining":
        return <TrendingUp className="w-4 h-4 text-red-600" />;
      default:
        return <Activity className="w-4 h-4 text-blue-600" />;
    }
  };

  // Analytics data
  const riskDistribution = [
    { name: "Low Risk", value: MOCK_PATIENTS.filter(p => p.riskLevel === "low").length, color: "#10b981" },
    { name: "Moderate Risk", value: MOCK_PATIENTS.filter(p => p.riskLevel === "moderate").length, color: "#f59e0b" },
    { name: "High Risk", value: MOCK_PATIENTS.filter(p => p.riskLevel === "high").length, color: "#ef4444" },
  ];

  const weeklyTrends = [
    { day: "Mon", avgRisk: 45, sessions: 12, alerts: 3 },
    { day: "Tue", avgRisk: 42, sessions: 15, alerts: 2 },
    { day: "Wed", avgRisk: 48, sessions: 14, alerts: 5 },
    { day: "Thu", avgRisk: 43, sessions: 16, alerts: 4 },
    { day: "Fri", avgRisk: 46, sessions: 13, alerts: 3 },
    { day: "Sat", avgRisk: 41, sessions: 18, alerts: 2 },
    { day: "Sun", avgRisk: 44, sessions: 17, alerts: 4 },
  ];

  const alertTypeDistribution = [
    { type: "Shallow Breathing", count: 45, severity: "moderate" },
    { type: "Rapid Breathing", count: 28, severity: "moderate" },
    { type: "Critical Bradypnea", count: 15, severity: "critical" },
    { type: "Irregular Pattern", count: 32, severity: "low" },
  ];

  const totalPatients = MOCK_PATIENTS.length;
  const highRiskPatients = MOCK_PATIENTS.filter(p => p.riskLevel === "high").length;
  const totalAlerts = MOCK_PATIENTS.reduce((sum, p) => sum + p.criticalAlerts, 0);
  const avgComplianceRate = 85; // Mock data

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      {/* Header Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total Patients</p>
                <p className="text-3xl mt-1">{totalPatients}</p>
              </div>
              <Users className="w-10 h-10 text-blue-600 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">High Risk</p>
                <p className="text-3xl mt-1 text-red-600">{highRiskPatients}</p>
              </div>
              <AlertTriangle className="w-10 h-10 text-red-600 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total Alerts</p>
                <p className="text-3xl mt-1">{totalAlerts}</p>
              </div>
              <Activity className="w-10 h-10 text-orange-600 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Compliance</p>
                <p className="text-3xl mt-1 text-green-600">{avgComplianceRate}%</p>
              </div>
              <TrendingUp className="w-10 h-10 text-green-600 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="patients">Patients</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Patient Risk Distribution</CardTitle>
                <CardDescription>Current risk level breakdown</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={riskDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {riskDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Weekly Monitoring Trends</CardTitle>
                <CardDescription>Average risk scores over the past week</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <LineChart data={weeklyTrends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis domain={[0, 100]} />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="avgRisk" stroke="#3b82f6" name="Avg Risk Score" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Session Activity</CardTitle>
                <CardDescription>Daily monitoring sessions completed</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={weeklyTrends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="sessions" fill="#10b981" name="Sessions" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Alert Types</CardTitle>
                <CardDescription>Most common breathing irregularities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {alertTypeDistribution.map((alert, idx) => (
                    <div key={idx}>
                      <div className="flex justify-between text-sm mb-2">
                        <span className="flex items-center gap-2">
                          <div
                            className={`w-3 h-3 rounded-full ${
                              alert.severity === "critical"
                                ? "bg-red-600"
                                : alert.severity === "moderate"
                                ? "bg-yellow-600"
                                : "bg-blue-600"
                            }`}
                          />
                          {alert.type}
                        </span>
                        <span className="font-medium">{alert.count}</span>
                      </div>
                      <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full ${
                            alert.severity === "critical"
                              ? "bg-red-600"
                              : alert.severity === "moderate"
                              ? "bg-yellow-600"
                              : "bg-blue-600"
                          }`}
                          style={{ width: `${(alert.count / 120) * 100}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Patients Requiring Attention</CardTitle>
              <CardDescription>High-risk patients with recent critical alerts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {MOCK_PATIENTS.filter(p => p.riskLevel === "high" || p.criticalAlerts > 5).map(patient => (
                  <div key={patient.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-slate-50">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <Users className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <p className="font-medium">{patient.name}</p>
                        <p className="text-sm text-slate-600">ID: {patient.id} • Age: {patient.age}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right text-sm">
                        <p className="text-slate-600">Critical Alerts</p>
                        <p className="font-medium text-red-600">{patient.criticalAlerts}</p>
                      </div>
                      <Badge className={getRiskColor(patient.riskLevel)}>{patient.riskLevel}</Badge>
                      <Button size="sm">View Details</Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="patients" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <CardTitle>Patient Directory</CardTitle>
                  <CardDescription>Manage and monitor all patients</CardDescription>
                </div>
                <div className="flex gap-2">
                  <div className="relative flex-1 md:w-64">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <Input
                      placeholder="Search patients..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                  <Select value={filterRisk} onValueChange={setFilterRisk}>
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder="Risk Level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Risks</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="moderate">Moderate</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {filteredPatients.map(patient => (
                  <div
                    key={patient.id}
                    className="border rounded-lg p-4 hover:bg-slate-50 transition cursor-pointer"
                    onClick={() => setSelectedPatient(patient.id)}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                          <span className="font-medium text-blue-600">{patient.name.charAt(0)}</span>
                        </div>
                        <div>
                          <p className="font-medium">{patient.name}</p>
                          <p className="text-sm text-slate-600">
                            {patient.id} • {patient.age} years old
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        {getTrendIcon(patient.trend)}
                        <Badge className={getRiskColor(patient.riskLevel)}>{patient.riskLevel}</Badge>
                      </div>
                    </div>
                    <div className="grid grid-cols-4 gap-4 text-sm">
                      <div>
                        <p className="text-slate-600">Sessions</p>
                        <p className="font-medium">{patient.totalSessions}</p>
                      </div>
                      <div>
                        <p className="text-slate-600">Avg Risk</p>
                        <p className="font-medium">{patient.avgRiskScore}</p>
                      </div>
                      <div>
                        <p className="text-slate-600">Alerts</p>
                        <p className="font-medium text-red-600">{patient.criticalAlerts}</p>
                      </div>
                      <div>
                        <p className="text-slate-600">Last Session</p>
                        <p className="font-medium">{patient.lastSession}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Population Analytics</CardTitle>
              <CardDescription>Insights across all monitored patients</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6 mb-6">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Wind className="w-5 h-5 text-blue-600" />
                    <span className="text-sm font-medium">Avg Breathing Rate</span>
                  </div>
                  <p className="text-2xl font-bold text-blue-600">15.8 bpm</p>
                  <p className="text-xs text-slate-600 mt-1">Normal range: 12-20 bpm</p>
                </div>
                <div className="p-4 bg-green-50 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Moon className="w-5 h-5 text-green-600" />
                    <span className="text-sm font-medium">Avg Session Duration</span>
                  </div>
                  <p className="text-2xl font-bold text-green-600">6.2 hrs</p>
                  <p className="text-xs text-slate-600 mt-1">Recommended: 7-9 hrs</p>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Heart className="w-5 h-5 text-purple-600" />
                    <span className="text-sm font-medium">Intervention Success</span>
                  </div>
                  <p className="text-2xl font-bold text-purple-600">89%</p>
                  <p className="text-xs text-slate-600 mt-1">Alerts resolved with intervention</p>
                </div>
              </div>

              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={weeklyTrends}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area type="monotone" dataKey="avgRisk" stackId="1" stroke="#3b82f6" fill="#93c5fd" name="Avg Risk" />
                  <Area type="monotone" dataKey="alerts" stackId="2" stroke="#f59e0b" fill="#fcd34d" name="Alerts" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Intervention Effectiveness</CardTitle>
                <CardDescription>Success rates by intervention type</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { name: "Anulom Vilom", success: 92 },
                    { name: "Diaphragmatic", success: 88 },
                    { name: "Bhramari", success: 85 },
                  ].map((intervention, idx) => (
                    <div key={idx}>
                      <div className="flex justify-between text-sm mb-2">
                        <span>{intervention.name}</span>
                        <span className="font-medium">{intervention.success}%</span>
                      </div>
                      <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-green-600"
                          style={{ width: `${intervention.success}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Compliance Trends</CardTitle>
                <CardDescription>Patient adherence to monitoring schedule</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={200}>
                  <LineChart data={weeklyTrends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis domain={[0, 20]} />
                    <Tooltip />
                    <Line type="monotone" dataKey="sessions" stroke="#10b981" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="reports" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Generate Reports</CardTitle>
              <CardDescription>Download detailed patient monitoring reports</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <FileText className="w-8 h-8 text-blue-600" />
                        <div>
                          <p className="font-medium">Individual Patient Report</p>
                          <p className="text-sm text-slate-600">Detailed analysis for single patient</p>
                        </div>
                      </div>
                    </div>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select Patient" />
                      </SelectTrigger>
                      <SelectContent>
                        {MOCK_PATIENTS.map(p => (
                          <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button className="w-full mt-3">
                      <Download className="w-4 h-4 mr-2" />
                      Download PDF
                    </Button>
                  </div>

                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <FileText className="w-8 h-8 text-green-600" />
                        <div>
                          <p className="font-medium">Population Summary</p>
                          <p className="text-sm text-slate-600">Overview of all patients</p>
                        </div>
                      </div>
                    </div>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Time Period" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="week">Last Week</SelectItem>
                        <SelectItem value="month">Last Month</SelectItem>
                        <SelectItem value="quarter">Last Quarter</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button className="w-full mt-3">
                      <Download className="w-4 h-4 mr-2" />
                      Download PDF
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <FileText className="w-8 h-8 text-purple-600" />
                        <div>
                          <p className="font-medium">Alert Summary Report</p>
                          <p className="text-sm text-slate-600">Critical alerts breakdown</p>
                        </div>
                      </div>
                    </div>
                    <Button className="w-full" variant="outline">
                      <Download className="w-4 h-4 mr-2" />
                      Download CSV
                    </Button>
                  </div>

                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <FileText className="w-8 h-8 text-orange-600" />
                        <div>
                          <p className="font-medium">Intervention Analytics</p>
                          <p className="text-sm text-slate-600">Effectiveness metrics</p>
                        </div>
                      </div>
                    </div>
                    <Button className="w-full" variant="outline">
                      <Download className="w-4 h-4 mr-2" />
                      Download Excel
                    </Button>
                  </div>
                </div>
              </div>

              <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-sm text-blue-900">
                  <strong>Note:</strong> All reports are generated in compliance with HIPAA and patient privacy regulations. 
                  Data is de-identified when appropriate and encrypted for secure transmission.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
