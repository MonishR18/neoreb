import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Separator } from "./ui/separator";
import {
  Camera,
  Brain,
  Database,
  Shield,
  Activity,
  Zap,
  CheckCircle2,
  AlertTriangle,
  Cloud,
  Lock,
  FileText,
} from "lucide-react";

export function SystemArchitecture() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">System Architecture & Documentation</h1>
        <p className="text-slate-600">
          Technical overview of the AI-powered camera-based monitoring system for Parkinson's sleep breathing
        </p>
      </div>

      <Tabs defaultValue="architecture" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="architecture">Architecture</TabsTrigger>
          <TabsTrigger value="ai-pipeline">AI Pipeline</TabsTrigger>
          <TabsTrigger value="alerts">Alert Logic</TabsTrigger>
          <TabsTrigger value="mvp">MVP Features</TabsTrigger>
          <TabsTrigger value="ethics">Ethics & Legal</TabsTrigger>
        </TabsList>

        {/* System Architecture */}
        <TabsContent value="architecture" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>System Components Overview</CardTitle>
              <CardDescription>Three-tier architecture with privacy-first design</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Frontend */}
                <div className="p-4 border-l-4 border-blue-600 bg-blue-50">
                  <div className="flex items-center gap-2 mb-3">
                    <Camera className="w-6 h-6 text-blue-600" />
                    <h3 className="text-lg font-medium">Frontend Layer</h3>
                  </div>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>React.js + TypeScript:</strong> Type-safe component architecture</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>WebRTC Camera Access:</strong> Real-time video capture via getUserMedia API</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Canvas API:</strong> Frame extraction for breathing analysis</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Progressive Web App:</strong> Installable on smartphones/tablets</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Responsive Design:</strong> Optimized for mobile and desktop devices</span>
                    </li>
                  </ul>
                </div>

                {/* AI Processing */}
                <div className="p-4 border-l-4 border-purple-600 bg-purple-50">
                  <div className="flex items-center gap-2 mb-3">
                    <Brain className="w-6 h-6 text-purple-600" />
                    <h3 className="text-lg font-medium">AI Processing Layer</h3>
                  </div>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Computer Vision Module:</strong> MediaPipe / TensorFlow.js for chest movement detection</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Motion Tracking:</strong> Optical flow analysis for breathing rate calculation</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Time-Series Analysis:</strong> LSTM/GRU models for pattern detection</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Low-Light Enhancement:</strong> Adaptive brightness and contrast processing</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Edge Processing:</strong> On-device inference for privacy (no video upload)</span>
                    </li>
                  </ul>
                </div>

                {/* Backend */}
                <div className="p-4 border-l-4 border-green-600 bg-green-50">
                  <div className="flex items-center gap-2 mb-3">
                    <Cloud className="w-6 h-6 text-green-600" />
                    <h3 className="text-lg font-medium">Backend & Data Layer</h3>
                  </div>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Node.js / Python FastAPI:</strong> REST API for data sync</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>PostgreSQL / MongoDB:</strong> Patient profiles & monitoring history</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Redis Cache:</strong> Real-time metrics and session state</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>AWS S3 / Cloud Storage:</strong> Encrypted metadata (no video storage)</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>WebSocket / Server-Sent Events:</strong> Real-time alert delivery</span>
                    </li>
                  </ul>
                </div>

                {/* Security */}
                <div className="p-4 border-l-4 border-red-600 bg-red-50">
                  <div className="flex items-center gap-2 mb-3">
                    <Shield className="w-6 h-6 text-red-600" />
                    <h3 className="text-lg font-medium">Security & Privacy</h3>
                  </div>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start gap-2">
                      <Lock className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                      <span><strong>End-to-End Encryption:</strong> AES-256 for all data at rest and in transit</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Lock className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Zero Video Storage:</strong> Only numerical metrics are saved</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Lock className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Granular Consent:</strong> Explicit opt-in for each data collection purpose</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Lock className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Data Retention:</strong> Automatic deletion after configurable period</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Lock className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                      <span><strong>HIPAA Compliance:</strong> Healthcare data protection standards</span>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* AI Pipeline */}
        <TabsContent value="ai-pipeline" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>AI Processing Pipeline</CardTitle>
              <CardDescription>Real-time breathing analysis workflow</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="text-center p-6 bg-blue-50 rounded-lg border-2 border-blue-200">
                    <div className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-3 text-xl font-bold">
                      1
                    </div>
                    <h4 className="font-medium mb-2">Video Acquisition</h4>
                    <p className="text-sm text-slate-600">
                      Capture at 15-30 FPS in low-light conditions using infrared or ambient light
                    </p>
                  </div>
                  <div className="text-center p-6 bg-purple-50 rounded-lg border-2 border-purple-200">
                    <div className="w-12 h-12 bg-purple-600 text-white rounded-full flex items-center justify-center mx-auto mb-3 text-xl font-bold">
                      2
                    </div>
                    <h4 className="font-medium mb-2">Preprocessing</h4>
                    <p className="text-sm text-slate-600">
                      Denoise, enhance contrast, and extract ROI (chest region)
                    </p>
                  </div>
                  <div className="text-center p-6 bg-green-50 rounded-lg border-2 border-green-200">
                    <div className="w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center mx-auto mb-3 text-xl font-bold">
                      3
                    </div>
                    <h4 className="font-medium mb-2">Feature Extraction</h4>
                    <p className="text-sm text-slate-600">
                      Detect chest movement amplitude, frequency, and micro-movements
                    </p>
                  </div>
                </div>

                <Separator />

                <div>
                  <h4 className="font-medium mb-4">Core Algorithms</h4>
                  <div className="space-y-4">
                    <div className="p-4 bg-slate-50 rounded-lg">
                      <h5 className="font-medium mb-2 flex items-center gap-2">
                        <Activity className="w-5 h-5 text-blue-600" />
                        Breathing Rate Detection
                      </h5>
                      <code className="text-sm bg-white p-3 block rounded border">
                        {`// Optical Flow Analysis
1. Extract consecutive frames (t, t+1)
2. Compute motion vectors in chest ROI
3. Apply FFT to motion signals
4. Identify respiratory frequency (0.15-0.4 Hz)
5. Convert to breaths per minute`}
                      </code>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-lg">
                      <h5 className="font-medium mb-2 flex items-center gap-2">
                        <Brain className="w-5 h-5 text-purple-600" />
                        LSTM Time-Series Model
                      </h5>
                      <code className="text-sm bg-white p-3 block rounded border">
                        {`// Pattern Detection
Input: [rate_t-n, ..., rate_t]  // Last 60 seconds
↓
LSTM(128 units) → Dropout(0.2)
↓
Dense(64, relu) → Dense(3, softmax)
↓
Output: [normal, shallow, irregular] probabilities`}
                      </code>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-lg">
                      <h5 className="font-medium mb-2 flex items-center gap-2">
                        <Zap className="w-5 h-5 text-yellow-600" />
                        Risk Score Calculation
                      </h5>
                      <code className="text-sm bg-white p-3 block rounded border">
                        {`// Multi-Factor Risk Scoring
riskScore = 
  w1 × breathingRateDeviation +
  w2 × varianceScore +
  w3 × apneaDuration +
  w4 × motionReduction +
  w5 × baselineRisk
  
// Weights personalized from questionnaire`}
                      </code>
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <h4 className="font-medium mb-3">Data Flow</h4>
                  <div className="bg-slate-900 text-white p-6 rounded-lg font-mono text-sm">
                    <div className="space-y-2">
                      <div>Camera → Video Frame (RGB)</div>
                      <div className="ml-4">↓ Grayscale conversion</div>
                      <div>Preprocessed Frame (320×240)</div>
                      <div className="ml-4">↓ MediaPipe pose detection</div>
                      <div>Chest ROI coordinates</div>
                      <div className="ml-4">↓ Motion vector calculation</div>
                      <div>Breathing signal (1D time-series)</div>
                      <div className="ml-4">↓ LSTM inference</div>
                      <div>Pattern classification + Risk score</div>
                      <div className="ml-4">↓ Alert logic</div>
                      <div>User notification / Intervention trigger</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Alert Logic */}
        <TabsContent value="alerts" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Tiered Alert System</CardTitle>
              <CardDescription>Three-level alert classification with appropriate interventions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Low Severity */}
                <div className="p-4 border-2 border-blue-300 rounded-lg bg-blue-50">
                  <div className="flex items-center gap-3 mb-3">
                    <Badge className="bg-blue-600">Low Severity</Badge>
                    <h4 className="font-medium">Informational Alerts</h4>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="font-medium mb-2">Trigger Conditions:</p>
                      <ul className="list-disc list-inside space-y-1 text-slate-700">
                        <li>Breathing rate 12-14 or 18-20 bpm</li>
                        <li>Minor variability (&gt;2 bpm std dev)</li>
                        <li>Risk score 20-30</li>
                      </ul>
                    </div>
                    <div>
                      <p className="font-medium mb-2">Response:</p>
                      <ul className="list-disc list-inside space-y-1 text-slate-700">
                        <li>Silent notification (no wake-up)</li>
                        <li>Log for morning review</li>
                        <li>Suggest breathing exercises for next day</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Moderate Severity */}
                <div className="p-4 border-2 border-yellow-300 rounded-lg bg-yellow-50">
                  <div className="flex items-center gap-3 mb-3">
                    <Badge className="bg-yellow-600">Moderate Severity</Badge>
                    <h4 className="font-medium">Active Intervention Required</h4>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="font-medium mb-2">Trigger Conditions:</p>
                      <ul className="list-disc list-inside space-y-1 text-slate-700">
                        <li>Breathing rate 10-12 or 20-22 bpm</li>
                        <li>Shallow breathing (&lt;50% chest expansion)</li>
                        <li>Irregular pattern for &gt;30 seconds</li>
                        <li>Risk score 30-60</li>
                      </ul>
                    </div>
                    <div>
                      <p className="font-medium mb-2">Response:</p>
                      <ul className="list-disc list-inside space-y-1 text-slate-700">
                        <li>Gentle vibration or audio cue</li>
                        <li>Guided breathing intervention</li>
                        <li>Monitor for 2 minutes post-intervention</li>
                        <li>Log event with severity</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Critical Severity */}
                <div className="p-4 border-2 border-red-300 rounded-lg bg-red-50">
                  <div className="flex items-center gap-3 mb-3">
                    <Badge className="bg-red-600">Critical Severity</Badge>
                    <h4 className="font-medium">Immediate Action Required</h4>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="font-medium mb-2">Trigger Conditions:</p>
                      <ul className="list-disc list-inside space-y-1 text-slate-700">
                        <li>Breathing rate &lt;10 or &gt;24 bpm</li>
                        <li>Apnea (&gt;20 seconds no breathing)</li>
                        <li>Sudden motion loss (rigidity)</li>
                        <li>Risk score &gt;60</li>
                      </ul>
                    </div>
                    <div>
                      <p className="font-medium mb-2">Response:</p>
                      <ul className="list-disc list-inside space-y-1 text-slate-700">
                        <li>Loud alarm to wake patient</li>
                        <li>Immediate intervention guidance</li>
                        <li>Option to call caregiver/emergency</li>
                        <li>Detailed incident report</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="p-4 bg-slate-50 rounded-lg">
                  <h4 className="font-medium mb-3">Alert Decision Tree</h4>
                  <code className="text-sm block">
                    {`if (breathingRate < 10) {
  severity = "critical"
  action = "wakePatient" + "triggerIntervention"
} else if (breathingRate < 12) {
  severity = "moderate"
  action = "gentleAlert" + "guidedBreathing"
} else if (variance > threshold) {
  severity = "low"
  action = "logOnly"
}

// Factor in baseline risk
if (patientRiskLevel === "high") {
  severity = escalate(severity)
  responseTime = faster()
}`}
                  </code>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* MVP Features */}
        <TabsContent value="mvp" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                  MVP Phase 1 (Months 1-3)
                </CardTitle>
                <CardDescription>Core functionality for initial testing</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-sm">
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-green-100 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle2 className="w-3 h-3 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium">Patient onboarding & baseline questionnaire</p>
                      <p className="text-slate-600">Collect medical history and baseline metrics</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-green-100 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle2 className="w-3 h-3 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium">Camera-based breathing detection</p>
                      <p className="text-slate-600">Basic motion tracking and rate calculation</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-green-100 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle2 className="w-3 h-3 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium">Simple alert system (2 levels)</p>
                      <p className="text-slate-600">Moderate and critical alerts only</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-green-100 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle2 className="w-3 h-3 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium">One guided intervention (Diaphragmatic)</p>
                      <p className="text-slate-600">Simplified breathing exercise</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-green-100 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle2 className="w-3 h-3 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium">Basic patient dashboard</p>
                      <p className="text-slate-600">Session history and simple charts</p>
                    </div>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-blue-600" />
                  Phase 2 (Months 4-6)
                </CardTitle>
                <CardDescription>Enhanced AI and clinical features</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-sm">
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-blue-100 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Activity className="w-3 h-3 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium">LSTM time-series model integration</p>
                      <p className="text-slate-600">Pattern recognition and prediction</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-blue-100 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Activity className="w-3 h-3 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium">All three intervention types</p>
                      <p className="text-slate-600">Anulom Vilom, Diaphragmatic, Bhramari</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-blue-100 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Activity className="w-3 h-3 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium">Weekly/monthly questionnaires</p>
                      <p className="text-slate-600">Adaptive risk assessment</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-blue-100 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Activity className="w-3 h-3 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium">Doctor dashboard with analytics</p>
                      <p className="text-slate-600">Patient management and reporting</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-blue-100 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Activity className="w-3 h-3 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium">Low-light optimization</p>
                      <p className="text-slate-600">IR support and image enhancement</p>
                    </div>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-purple-600" />
                  Phase 3 (Months 7-12)
                </CardTitle>
                <CardDescription>Advanced features and scalability</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-sm">
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-purple-100 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Zap className="w-3 h-3 text-purple-600" />
                    </div>
                    <div>
                      <p className="font-medium">Facial micro-movement analysis</p>
                      <p className="text-slate-600">Enhanced distress detection</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-purple-100 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Zap className="w-3 h-3 text-purple-600" />
                    </div>
                    <div>
                      <p className="font-medium">Multi-patient monitoring</p>
                      <p className="text-slate-600">Care facility deployment</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-purple-100 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Zap className="w-3 h-3 text-purple-600" />
                    </div>
                    <div>
                      <p className="font-medium">EHR integration (FHIR compatible)</p>
                      <p className="text-slate-600">Seamless clinical workflow</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-purple-100 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Zap className="w-3 h-3 text-purple-600" />
                    </div>
                    <div>
                      <p className="font-medium">Predictive analytics</p>
                      <p className="text-slate-600">Risk forecasting 24-48 hours ahead</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-purple-100 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Zap className="w-3 h-3 text-purple-600" />
                    </div>
                    <div>
                      <p className="font-medium">Multi-language support</p>
                      <p className="text-slate-600">Hindi, Tamil, Telugu, Bengali, etc.</p>
                    </div>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-orange-600" />
                  Clinical Validation Plan
                </CardTitle>
                <CardDescription>Path to medical device approval</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-sm">
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-orange-100 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                      <FileText className="w-3 h-3 text-orange-600" />
                    </div>
                    <div>
                      <p className="font-medium">Pilot study (n=30 patients)</p>
                      <p className="text-slate-600">Validate against polysomnography</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-orange-100 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                      <FileText className="w-3 h-3 text-orange-600" />
                    </div>
                    <div>
                      <p className="font-medium">Multi-center trial (n=200)</p>
                      <p className="text-slate-600">Sensitivity, specificity metrics</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-orange-100 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                      <FileText className="w-3 h-3 text-orange-600" />
                    </div>
                    <div>
                      <p className="font-medium">FDA/CDSCO submission</p>
                      <p className="text-slate-600">Class II medical device pathway</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 bg-orange-100 rounded flex items-center justify-center flex-shrink-0 mt-0.5">
                      <FileText className="w-3 h-3 text-orange-600" />
                    </div>
                    <div>
                      <p className="font-medium">Long-term outcomes study</p>
                      <p className="text-slate-600">Impact on quality of life metrics</p>
                    </div>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Ethics & Legal */}
        <TabsContent value="ethics" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Ethical Considerations</CardTitle>
              <CardDescription>Privacy, safety, and responsible AI principles</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="p-4 border-l-4 border-blue-600 bg-blue-50">
                  <h4 className="font-medium mb-2 flex items-center gap-2">
                    <Shield className="w-5 h-5 text-blue-600" />
                    Privacy-First Design
                  </h4>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>No video storage:</strong> All processing happens in real-time on device</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Minimal data retention:</strong> Only numerical metrics saved, auto-deleted after 1 year</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>User control:</strong> Delete data anytime, export in portable format</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Transparent AI:</strong> Explain why each alert was triggered</span>
                    </li>
                  </ul>
                </div>

                <div className="p-4 border-l-4 border-yellow-600 bg-yellow-50">
                  <h4 className="font-medium mb-2 flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-yellow-600" />
                    Clinical Safety
                  </h4>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Not a diagnostic device:</strong> Clear disclaimers that this is monitoring, not diagnosis</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                      <span><strong>False positive management:</strong> Avoid alarm fatigue through smart thresholds</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Emergency escalation:</strong> Easy 1-click caregiver/911 contact</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Failsafe mechanisms:</strong> Backup battery, offline mode, regular calibration</span>
                    </li>
                  </ul>
                </div>

                <div className="p-4 border-l-4 border-green-600 bg-green-50">
                  <h4 className="font-medium mb-2 flex items-center gap-2">
                    <FileText className="w-5 h-5 text-green-600" />
                    Regulatory Compliance
                  </h4>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>HIPAA (USA):</strong> Encrypted PHI, audit logs, Business Associate Agreements</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>GDPR (EU):</strong> Right to erasure, data portability, consent management</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>IT Act (India):</strong> Reasonable security practices, sensitive personal data rules</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span><strong>FDA Class II:</strong> 510(k) pathway as wellness/monitoring device</span>
                    </li>
                  </ul>
                </div>

                <div className="p-4 border-l-4 border-purple-600 bg-purple-50">
                  <h4 className="font-medium mb-2 flex items-center gap-2">
                    <Brain className="w-5 h-5 text-purple-600" />
                    AI Ethics & Explainability
                  </h4>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Transparent models:</strong> SHAP values and attention visualization for interpretability</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Bias mitigation:</strong> Diverse training data across age, gender, ethnicity</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Human oversight:</strong> Doctors review high-risk cases, not fully automated</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                      <span><strong>Continuous monitoring:</strong> Track model drift, retrain quarterly</span>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Deployment Strategy for India</CardTitle>
              <CardDescription>Affordable, accessible, and culturally appropriate</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-3">Cost Optimization</h4>
                  <ul className="space-y-2 text-sm">
                    <li>• Smartphone-only (no specialized hardware)</li>
                    <li>• Freemium model: Basic free, Premium ₹299/month</li>
                    <li>• Partner with insurance (Ayushman Bharat)</li>
                    <li>• Government hospital subsidies</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium mb-3">Accessibility</h4>
                  <ul className="space-y-2 text-sm">
                    <li>• Offline mode for low-connectivity areas</li>
                    <li>• Voice interface (Hindi, regional languages)</li>
                    <li>• Simple UI for elderly patients</li>
                    <li>• Caregiver portal for family support</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
